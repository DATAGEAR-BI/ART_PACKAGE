$(document).ready(function() {


	var options = {
		allow_empty: true,

		filters: [
			{
				id: 'name',
				label: 'Name',
				type: 'string',
				// optgroup: 'core',
				default_value: 'gaur',
				size: 30,
				unique: true
			},
						{
				id: 'value',
				label: 'value',
				type: 'string',
				// optgroup: 'core',
				default_value: 'gaur',
				size: 30,
				unique: true
			}
		]
	};


	$('#builder').queryBuilder(options);
	var query = '';

	$('.parse-json').on('click', function() {
			// var res =  JSON.stringify($('#builder').queryBuilder('getSQL','question_mark'));
			console.log(JSON.stringify($('#builder').queryBuilder('getSQL')));
			console.log($('#builder').queryBuilder('getSQL').sql);
			var jsonObj = $('#builder').queryBuilder('getSQL');
			console.log(jsonObj);

				for(var key in jsonObj)
				{	
					var str = JSON.stringify(jsonObj[key]).split('"')[0];
					console.log(str);
					// query += jsonObj[key].split(' ')[0];
				}
			// console.log(query);
			$('#append').append('<p>SELECT '+jsonObj['sql'].split(' ')[0]+' FROM FSC_PREDICTIONS WHERE '+
				jsonObj['sql'] +'=' + jsonObj['params'][0]
				+'</p>');
	
	});



});